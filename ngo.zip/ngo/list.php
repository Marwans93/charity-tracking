<?php
  session_start();
 
  
 include '../googleMap/config.php';

  if(!$_SESSION['login'])
    header('Location:../index.php');
  
  else
  {
  
  
  //pagination
  
  if (isset($_GET["start"]))
  { $start = $_GET["start"]; }
  else
  { $start =''; }

  if(isset($_GET['limitation']))
  { $limitShow = $_GET['limitation'];}
  else
  { $limitShow = "5";}
  
  //paging
  if(!isset($start))
    { $start = 0; }                 
  
    $eu = ($start - 0);
    $limit = $limitShow;
    $thispage = $eu + $limit;
    $back = $eu - $limit;
    $next = $eu + $limit;
  $first = 0;
  
  //search by number
  
  $search = 'x';
  $status = "";
  $info = ""; 
  
  if(isset($_GET['status']))
  { $info = $_GET['status'];}
  else
  {   $info = "";}
  
  if(!$info == 0)
  {
    if($info == "fsd")
    {
      $showInfo = "<font face='arial' size='2' color='green'>Location Successfully Deleted</font>";
    }
    if($info == "fse")
    {
      $showInfo = "<font face='arial' size='2' color='green'>Location Successfully Edit</font>";
    }
  }
  else
  {
    $showInfo = "";
  }
  
    
  
  if(isset($_REQUEST['submit']))
  {
    $button = $_REQUEST['submit'];
  }
  else
  {
    $button = "";
  }
  
  
  
  
  if($button == "")
  {
        $location = "select * from locations order by type asc limit $eu,$limit";
        $queuelocation = mysql_query($location) or die(mysql_error());
        
        $select = "select * from locations";
        $qSelect = mysql_query($select) or die(mysql_error());
        $rows = mysql_num_rows($qSelect);
        
        
  }
  elseif(isset($button))
  { 
    if($button == "Search")
    {
      if(isset($_POST['search']))
      { 
        $search = $_POST['search'];
      }
      
      else
      {
        $search = '';
      }
        
      if(!$search=="")
      {
          $status = "s";
          $locations = "select * from locations where type like '%$search%' or type like '$search%' order by category asc limit $eu,$limit";
          $queuelocation = mysql_query($locations) or die(mysql_error());
          $rows = mysql_num_rows($queuelocations);
    
      }
      else
      {
        $locations = "select * from locations order by type asc limit $eu,$limit";
        $queuelocation = mysql_query($location) or die(mysql_error());
        
        $select = "select * from locations";
        $qSelect = mysql_query($select) or die(mysql_error());
        $rows = mysql_num_rows($qSelect);
      }
      
      
    }
    
    elseif($button="Search Category")
    {
    
      if(isset($_POST['searchByCategory']))
      {
        $searchByCategory = $_POST['searchByCategory'];
      }
  
      else
      {
        $searchByCategory = '';
      }
    
      
      if(!$searchByCategory=="")
      {
          $status = "sbc";
          $locations = "select * from locations where type like '$searchByCategory%' order by type asc limit $eu,$limit";
          $queuelocation = mysql_query($locations) or die(mysql_error());
          $rows = mysql_num_rows($queuelocation);
        
      }
      else
      {
        $locations = "select * from locations order by type asc limit $eu,$limit";
        $queuelocation = mysql_query($locations) or die(mysql_error());
        
        $select = "select * from locations";
        $qSelect = mysql_query($select) or die(mysql_error());
        $rows = mysql_num_rows($qSelect);
      }
      
      
    }
    
  }
  if(!$status == "")
  { 
    $statusCompare = $status;
    if($statusCompare == "sbc")
    {
      $showStatus = "<font face='arial' size='2' color='green'>Searching of category ".$searchByCategory."</font>";
    }
    elseif($statusCompare == "s")
    {
      $showStatus = "<font face='arial' size='2' color='green'>Searching of ".$search."</font>";
    }
    elseif($statusCompare == "s")
    {
      $showStatus = "<font face='arial' size='2' color='green'>Searching of ".$search."</font>";
    }
    
  }
  else
  {
    $showStatus = "&nbsp;";
  }
  
  
  
  
?>
<html>
    <head>
    <meta name="keywords" content="" />
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="UTF-8">


    <!-- CSS Bootstrap & Custom -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/templatemo_misc.css">

    <!-- Main CSS -->
    <link rel="stylesheet" href="css/templatemo_style.css">

    <!-- Favicons -->
    <link rel="shortcut icon" href="images/ico/favicon.ico">

<script type="text/javascript">
 $(function() {
        /* For zebra striping */
        $("table tr:nth-child(odd)").addClass("odd-row");
        /* For cell text alignment */
        $("table td:first-child, table th:first-child").addClass("first");
        /* For removing the last border */
        $("table td:last-child, table th:last-child").addClass("last");
});
</script>

<style type="text/css">

    a {color:#666;}
    
    #content {width:65%; max-width:690px; margin:6% auto 0;}
    
    /*
    Pretty Table Styling
    CSS Tricks also has a nice writeup: http://css-tricks.com/feature-table-design/
    */
    
    table {
        overflow:hidden;
        border:1px solid #d3d3d3;
        background:#fefefe;
        width:40%;
        margin:5% auto 0;
        -moz-border-radius:5px; /* FF1+ */
        -webkit-border-radius:5px; /* Saf3-4 */
        border-radius:5px;
        -moz-box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
        -webkit-box-shadow: 0 0 4px rgba(0, 0, 0, 0.2);
    }
    
    th, td {padding:8px 18px 8px; text-align:center; }
    
    th {padding-top:8px; text-shadow: 1px 1px 1px #fff; background:#e8eaeb;}
    
    td {border-top:1px solid #e0e0e0; border-right:1px solid #e0e0e0;}
    
    tr.odd-row td {background:#f6f6f6;}
    
    td.first, th.first {text-align:left}
    
    td.last {border-right:none;}
    
    /*
    Background gradients are completely unnecessary but a neat effect.
    */
    
    td {
        background: -moz-linear-gradient(100% 25% 90deg, #fefefe, #f9f9f9);
        background: -webkit-gradient(linear, 0% 0%, 0% 25%, from(#f9f9f9), to(#fefefe));
    }
    
    tr.odd-row td {
        background: -moz-linear-gradient(100% 25% 90deg, #f6f6f6, #f1f1f1);
        background: -webkit-gradient(linear, 0% 0%, 0% 25%, from(#f1f1f1), to(#f6f6f6));
    }
    
    th {
        background: -moz-linear-gradient(100% 20% 90deg, #e8eaeb, #ededed);
        background: -webkit-gradient(linear, 0% 0%, 0% 20%, from(#ededed), to(#e8eaeb));
    }
    
    /*
    I know this is annoying, but we need additional styling so webkit will recognize rounded corners on background elements.
    Nice write up of this issue: http://www.onenaught.com/posts/266/css-inner-elements-breaking-border-radius
    
    And, since we've applied the background colors to td/th element because of IE, Gecko browsers also need it.
    */
    
    tr:first-child th.first {
        -moz-border-radius-topleft:5px;
        -webkit-border-top-left-radius:5px; /* Saf3-4 */
    }
    
    tr:first-child th.last {
        -moz-border-radius-topright:5px;
        -webkit-border-top-right-radius:5px; /* Saf3-4 */
    }
    
    tr:last-child td.first {
        -moz-border-radius-bottomleft:5px;
        -webkit-border-bottom-left-radius:5px; /* Saf3-4 */
    }
    
    tr:last-child td.last {
        -moz-border-radius-bottomright:5px;
        -webkit-border-bottom-right-radius:5px; /* Saf3-4 */
    }

</style>
</head>

    <!-- Main HTML -->
    
<body>
    
    
<!-- ########################################## close header ########################################## -->
    
<div class="site-header">
    
        <div class="main-navigation"> <!-- main-navigation -->
            <div class="responsive_menu"> <!-- responsive_menu -->
                <ul>
                    

                </ul>
            </div> <!-- responsive_menu -->
            
            <div class="container"> <!-- container -->
                <div class="row"> <!-- row -->
                
                    <div class="col-md-12 responsive-menu"> <!-- col-md-12 -->
                        
                    </div> <!-- /.col-md-12 -->
                    
                    <div class="col-md-12 main_menu"> <!-- col-md-12 -->
                        
                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->
            </div> <!-- /.container -->
        </div> <!-- /.main-navigation -->
           <!-- ########################################## title ##########################################-->
        
        <div class="container"> <!-- container -->
            <div class="row"> <!-- row -->
                <div class="col-md-12 text-center"> <!-- col-md-12 -->
                    <a href="#" class="templatemo_logo"> <!-- logo -->
                        <h1>List of Location</h1>
                    </a> <!-- /.logo -->
                </div> <!-- /.col-md-12 -->
            </div> <!-- /.row -->
        </div> <!-- /.container -->
        
    <!-- ########################################## close header ########################################## -->
    
<!-- ########################################## body ########################################## -->

    
    <div id="menu-container">

        <div class="content homepage" id="menu-1">
        
           <div class="container">
                
                <div class="row">
                    
                    <div class="widget-content"> 

    <?php

   
    
   $sql = "SELECT * FROM locations ";

   $query = mysql_query($sql);

?>
<!-- ############################################################## Table Searching #############################################################-->    
    <table>
    <tr>
      <th colspan="3">Searching Sectors</th>
    </tr>
    <tr>
      <td>
        <form name="search" method="post" action="list.php">
          <select name="searchByCategory">
          <option selected value="">Search By Category</option>
          <?php 
            
            $category = mysql_query("select * from locations");
          
            while($dataCategory = mysql_fetch_array($category))
            {
          ?></option>
          <option value="<?php echo $dataCategory['type']?>"><?php echo $dataCategory['type']?></option>
          <?php
          }
          ?>
          </select>
          <a><input type="submit" name="submit" value="  Search Category  " id="submit" class="button"></a>
        </form>
      </td>
    </tr> 
    
    </table>
  <!-- ############################################################## Close Table Searching #############################################################-->    
    <div align="center">
    <?php echo $showInfo; ?>
    </div>
    
<span class="counter pull-right"></span>
<table class="table table-hover table-bordered results">
  <thead>
    <th>No </div></th>
    <th>Name </div></th>
    <th>Address </div></th>
    <th>Category </div></th>
    <th>Latitude </div></th>
    <th>Longitude </div></th>
    <th colspan="2">Action </div></th>
    
  </tr>
   <?php
      
      $count = $start + 1;
      
      while($dataFile = mysql_fetch_array($queueFile))
      {   
      ?>
      <tr>
        <td width="1%"><?php echo $count++;?></td>
<?php
while($result=mysql_fetch_array($query,MYSQL_ASSOC))
{
?>
  <tr>
    <td width="1%"><?php echo $count++;?></td>
    <td><div align="center"><?php echo $result["id"];?></div></td>
    <td><?php echo $result["name"];?></td>
    <td><?php echo $result["ReturnedAddress"];?></td>
    <td><div align="center"><?php echo $result["type"];?></div></td>
    <td align="right"><?php echo $result["lat"];?></td>
    <td align="right"><?php echo $result["long"];?></td>
    <td width="7%" align="center"><a href="lagi_pengurus.php?no=<?php echo $dataPengurus['pengurusID']; ?>"><img src="images/lagi.png" onMouseOver="this.src='images/lagi2.png'" onMouseOut="this.src='images/lagi.png'"></a></td>
      <td width="7%" align="center"><a href="proses_hapus.php?no=<?php echo $dataPengurus['pengurusID'];?>"><img src="images/hapus.png" onMouseOver="this.src='images/hapus2.png'" onMouseOut="this.src='images/hapus.png'"></a></td> 
  </tr>
  
  <?php
      }
      ?>
      <tr><form action="list.php" method="get">
        <td colspan="8">        <p align="left">
        <?php

      $total = $rows;
      $last = $rows-$limit;
    
      // set paging
      if(!$start == 0){ print "<a href='list.php?start=$first&limitation=$limitShow' >First&nbsp;</a>";}
          if($back >= 0){ print "<a href='list.php?start=$back&limitation=$limitShow' ><<&nbsp;</a>";}

          $j=0;
          $l=1;

          for($j=0; $j<$total; $j=$j+$limit)
          {
              if($j <> $eu){ echo "&nbsp;&nbsp;<a href='list.php?start=$j&limitation=$limitShow'>$l</a> ";}
              else{ echo "&nbsp;<font color=red>$l</font>";}
   
            $l=$l+1;
          }

          if($thispage < $total){ echo "&nbsp;&nbsp;<a href='list.php?start=$next&limitation=$limitShow'>>></a>";}
      if($thispage < $total){ echo "&nbsp;&nbsp;<a href='list.php?start=$last&limitation=$limitShow'>Last</a>";}
        
        ?> 
      | Total Data: <?php echo $total;?> | 
      Limit Showing : 
        <select name="limitation" onChange="this.form.submit();">
          <option value="5" <?php if($limitShow == "5"){ echo "selected"; }?>>5</option>
            <option value="10" <?php if($limitShow == "10"){ echo "selected"; }?>>10</option>
          <option value="15" <?php if($limitShow == "15"){ echo "selected"; }?>>15</option>
          <option value="20" <?php if($limitShow == "20"){ echo "selected"; }?>>20</option>
        </select>
  <!--<a href="print_header_listFile.php" target="_blank">
 <a href="print_header_listFile.php?FileNumber=<?php//echo $dataFile['t10FileNumber']; ?>" target="_blank"> 
        <input name="button" type="button"  value="     Print      ">
        <input type="submit" name="cetak" id="cetak" value="CETAK HALAMAN INI" onclick="window.print();"  class="hide"; />
        <input name="button" type="button"  value="Print" onclick="window.print();"> -->
       

        </a></form>
        
        </p>
        </td>
      </tr>
      </table>
<!-- ############################################################## Close Table List All File #############################################################-->  
      
      
          </div>
              
        </div>
    
      </div>
      
    </div> <!-- /.menu-1 -->

  </div> <!-- /#menu-container -->

<!-- ########################################## close body ########################################## --> 

<!-- ########################################## open footer ########################################## -->    
<?php include ('bottom.php');?>

<!-- ########################################## close footer ########################################## --> 

  <!-- Scripts -->
  <script src="js/jquery-1.10.2.min.js"></script>
    <script src="js/jquery-migrate-1.2.1.min.js"></script>
    <script src="js/modernizr.js"></script>
  <script src="js/bootstrap.js"></script>
  <script src="js/tabs.js"></script>
  <script src="js/jquery.lightbox.js"></script>
  <script src="js/templatemo_custom.js"></script>
  
  <!-- End Page Content -->
 </body>
</html>

<?php
}
?>