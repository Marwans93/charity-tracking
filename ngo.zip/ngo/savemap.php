<html>
    <head>
    <script type='text/javascript' src='js/jquery-1.6.2.min.js'></script>

    <script type='text/javascript' src='js/jquery-ui.min.js'></script>
   
    </head>
    <body>
    <?php
    ini_set('display_errors', 1);
    error_reporting(~0);

   include '../googleMap/config.php';

        $id = $_POST["id"];
        $lat = $_POST["lat"];
        $long = $_POST["long"];
        $name = $_POST["Name"];
        $ReturnedAddress = $_POST["ReturnedAddress"];
        $type = $_POST["Type"];

        mysql_query("insert into locations values ('$id','$lat','$long','$name','$ReturnedAddress','$type')") or die (mysql_error());

      $maklum = $id." Berjaya di add!";
            
            header("Location:index.php?status=$maklum");

$sqldata = mysql_query($dbconnect,$sqlget) or die ('Error!');
    
?>
    </body>
</html>