<?php
    session_start();
    
    include '../user/config.php';
  

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Charity Location Tracking</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://bootstraptaste.com" />
<!-- css -->
<link href="../css/bootstrap.min.css" rel="stylesheet" />
<link href="../css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="../css/jcarousel.css" rel="stylesheet" />
<link href="../css/flexslider.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />

<!-- Theme skin -->
<link href="skins/default.css" rel="stylesheet" />

<!-- =======================================================
    Theme Name: Moderna
    Theme URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
======================================================= -->

</head>
    <!-- Main HTML -->
<body>
<div id="wrapper">
    <!-- start header -->
    <header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><span>C</span>harity</a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="edit_user.php">Manage Account</a></li>
                        <li><a href="charityForm.php">Add Charity Donation</a></li>
                        <li><a href="maps.php">View Maps Location</a></li>
                        <li><a href="recommendplace.php">Recommended Charity</a></li>
                        <li><a href="proses_log_keluar.php">Log Out</a></li>      
                    </ul>
                </div>
            </div>
        </div>
    </header>
    <section id="inner-headline">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <ul class="breadcrumb">
                    <li><a href="#"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
                    <li class="active">Recommended Charity Location</li>
                </ul>
            </div>
        </div>
    </div>
    </section>
</section>
    <section class="callaction">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="big-cta">
                    <div class="cta-text">
                        <h2><span>Find Nearest Charity Location</span></h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </section>
   <section id="content">
    <div class="container"> 

        <table align="center">
        <div class="form-group">
        <tr>
            <td><label for="category">Category </label></td>
            <td>
                <div class="form-group">
                <select name="category" class="form-control">
                        <option value="option">Select your category</option>
                        <option value="option1">Animal</option>
                        <option value="option2">Arts,Culture and Humanities</option>
                        <option value="option3">Community Development</option>
                        <option value="option4">Education</option>
                        <option value="option5">Enviroment</option>
                        <option value="option6">Health</option>
                        <option value="option7">Human and Civil Rights</option>
                        <option value="option8">Human Services</option>
                        <option value="option9">International</option>
                        <option value="option10">Research and Public Policy</option>
                        <option value="option11">Religion</option>
                 <div class="validation"></div>
                </select>
                </div>
            </td>
        </tr>
        <tr>
        <td><label for="name">Current Location </label></td>
        <td>
        <div class="form-group">
         <script type="text/javascript">
                  function showPosition(){
                          if(navigator.geolocation){
                              navigator.geolocation.getCurrentPosition(function(position){
                                  var positionInfo = "Latitude: " + position.coords.latitude +'<br>' + "Longitude: " + position.coords.longitude;
                                         document.getElementById("result").innerHTML = positionInfo;
                                         });
                                } else{
                                       alert("Sorry, your browser does not support.");
                                      }
                                }
                   </script>
            </head>
            <div id="result">
        <!--Position information will be inserted here-->
           </div>
           <button type="button"  class="form-control" name="coordinates" onclick="showPosition();">Show your current coordinates</button><br><br>
           <div class="validation"></div>
                </div>
            </td>
           </tr>
           </table>
           <center>
          <div class="text-center">
            <tr>
            <input type="submit" name="daftar" class="btn btn-theme" value="Track Location" >
            
            <br><br>
            </tr>
        </div>
        </center>
           
  </div>
                            
                </div>
        
            </div>
            
        </div> <!-- /.menu-1 -->

    </div> <!-- /#menu-container -->

<script>
function init() {
    // Create the autocomplete helper, and associate it with an HTML text input box.
    var autocomplete = new google.maps.places.Autocomplete(document.getElementById('queryinput'));
    function onAutocompleteValidate () {
        var placeResult = autocomplete.getPlace();

        if (!placeResult.geometry) {
          return;
        }

        var latitude = placeResult.geometry.location.lat();
        var longitude = placeResult.geometry.location.lng();
        // Search the assets around your location
        searchWoosmapApiAroundLocation(latitude, longitude);
        //Contribute to Woosmap Profile
        woosmapRecommendation.sendUserSearchedPosition({
            lat: latitude,
            lng: longitude
        });
    }

    google.maps.event.addListener(autocomplete, 'place_changed', onAutocompleteValidate);
}
</script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAOKFOE6G5cRGF_fcTYQuf5IVY9OviFZiw">
</script>


<!-- ########################################## footer ########################################## -->   
<footer>
    <div id="footer">
        <div class="container">
            <?php include ('bottom.php');?>
        </div>
    </div>
    </footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.fancybox.pack.js"></script>
<script src="../js/jquery.fancybox-media.js"></script>
<script src="../js/google-code-prettify/prettify.js"></script>
<script src="../js/portfolio/jquery.quicksand.js"></script>
<script src="../js/portfolio/setting.js"></script>
<script src="../js/jquery.flexslider.js"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script>
<script src="../contactform/contactform.js"></script>
</body>
</html>