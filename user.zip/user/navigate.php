<iframe width="300" height="350" frameborder="0" style="border:0" src="https://www.google.com/maps/embed/v1/directions?key=AIzaSyCY-FXEXzDxniMUUldFyEORqYguP9WiwJc &origin=<bubble's origin's formatted address>&destination=<bubble destination formatted address>"> </iframe> [image] [image]`

<!DOCTYPE html>
 <html> 
 <head> 
   <meta http-equiv="content-type" content="text/html; charset=UTF-8"/> 
   <title>Directions between places</title>
<style>
  html, body {
    height: 100%;
    margin: 0;
    padding: 0;
  }
  #map {
    height: 100%;
  }
</style> 
   <script type="text/javascript" 
           src="http://maps.google.com/maps/api/js?key=AIzaSyCY-FXEXzDxniMUUldFyEORqYguP9WiwJc"></script>
</head> 
<body> 
   <div id="map"></div>       
   <script type="text/javascript"> 
     var directionsService = new google.maps.DirectionsService();
     var directionsDisplay = new google.maps.DirectionsRenderer();

     var map = new google.maps.Map(document.getElementById('map'), {
       zoom:7,
       mapTypeId: google.maps.MapTypeId.ROADMAP
     });
    
     directionsDisplay.setMap(map);

     var request = {
       origin: 'bubble origin formatted as address', destination: 'bubble destination formatted as address',
       travelMode: google.maps.DirectionsTravelMode.DRIVING
     };

     directionsService.route(request, function(response, status) {
       if (status == google.maps.DirectionsStatus.OK) {
         directionsDisplay.setDirections(response);
       }
     });
   </script> 
</body> 
</html>`