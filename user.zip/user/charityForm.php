<?php
	session_start();
	
	include '../user/config.php';
  

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Charity Location Tracking</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://bootstraptaste.com" />
<!-- css -->
<link href="../css/bootstrap.min.css" rel="stylesheet" />
<link href="../css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="../css/jcarousel.css" rel="stylesheet" />
<link href="../css/flexslider.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />

<!-- Theme skin -->
<link href="skins/default.css" rel="stylesheet" />

<!-- =======================================================
    Theme Name: Moderna
    Theme URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
======================================================= -->

</head>
	<!-- Main HTML -->
<body>
<div id="wrapper">
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><span>C</span>harity</a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="edit_user.php">Manage Account</a></li>
                        <li><a href="charityForm.php">Add Charity Donation</a></li>
                        <li><a href="maps.php">View Maps Location</a></li>
                        <li><a href="recommendplace.php">Recommended Charity</a></li>
                        <li><a href="proses_log_keluar.php">Log Out</a></li>      
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="#"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
					<li class="active">Charity Form</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
</section>
	<section class="callaction">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="big-cta">
					<div class="cta-text">
						<h2><span>Charity Donation Form </span></h2>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
	<!-- Main HTML -->
	
<body>
	
<!-- ########################################## body ########################################## -->

	
	<section id="content">
	<div class="container"> 

		<table align="center">
        <form action="proses_charity.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
        <tr>			
			<td><label for="name">Charity Id:</label></td>
			<td>
			    <div class="form-group">
			    <input type="text" id="input3" name="charityId" class="form-control" placeholder="Charity Id" required />
			    <div class="validation"></div>
			    </div>
			</td>
		</tr>
		<tr>			
			<td><label for="name">Name:</label></td>
			<td>
			    <div class="form-group">
			    <input type="text" id="input3" name="name" class="form-control" placeholder="Enter your name" required />
			    <div class="validation"></div>
			    </div>
		    </td>
		</tr>
		<tr>
			<td><label for="name">Contact Number:</label></td>
			<td>
			    <div class="form-group">
			    <input type="text"  id="input3" name="fon" class="form-control" placeholder= "Fon number" required /></td>
			    <div class="validation"></div>
			    </div>
			</td>
		</tr>	
		<tr>
			<td><label for="category">Category:</label></td>
			<td>
			    <div class="form-group">
			    <select name="category" class="form-control">
                        <option value="option">Select your category</option>
                        <option value="option1">Animal</option>
                        <option value="option2">Arts,Culture and Humanities</option>
                        <option value="option3">Community Development</option>
                        <option value="option4">Education</option>
                        <option value="option5">Enviroment</option>
                        <option value="option6">Health</option>
                        <option value="option7">Human and Civil Rights</option>
                        <option value="option8">Human Services</option>
                        <option value="option9">International</option>
                        <option value="option10">Research and Public Policy</option>
                        <option value="option11">Religion</option>
                 <div class="validation"></div>
                </select>
                </div>
            </td>
		</tr>
		<tr>
			<td><label for="name">Description:</label></td>
			<td>
			    <div class="form-group">
			    <textarea name="desc" rows="5" cols="40" class="form-control" placeholder="Explain about your charity" required /></textarea></td>
			    <div class="validation"></div>
			    </div>
			</td>
		</tr>
		<tr>
			<td><label for="name">Picture:</label></td>
			<td>
			     <div class="form-group"> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="file" name="picture" class="form-control">
			     <div class="validation"></div>
			</div>
			</td>
		</tr>
		</tr>
		<tr>
			<td><label for="name">Address:</label></td>
			<td>
			    <div class="form-group">
			    <textarea name="address" rows="5" cols="40" class="form-control" placeholder="Enter your address" required /></textarea>
			     <div class="validation"></div>
			    </div>
			</td>
		</tr>
		</table><br>
		<center>
		  <div class="text-center">
			<tr>
			<input type="submit" name="daftar" class="btn btn-theme" value="Add" >
			<input type="reset"  class="btn btn-theme" name="reset" value="reset" ></th>
			<br><br>
		</div>
		</center>
		
		</form>
	               </div>
							
				</div>
		
			</div>
			
		</div> <!-- /.menu-1 -->

	</div> <!-- /#menu-container -->
<footer>
	<div id="footer">
		<div class="container">
			<?php include ('bottom.php');?>
		</div>
	</div>
	</footer>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.fancybox.pack.js"></script>
<script src="../js/jquery.fancybox-media.js"></script>
<script src="../js/google-code-prettify/prettify.js"></script>
<script src="../js/portfolio/jquery.quicksand.js"></script>
<script src="../js/portfolio/setting.js"></script>
<script src="../js/jquery.flexslider.js"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script>
<script src="../contactform/contactform.js"></script>


</body>
</html>
	
	
	
	
	
		
	