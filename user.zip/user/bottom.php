<footer>
	<div id="footer">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="copyright">
						<p>&copy; 2017 | Charity Location Tracking Web Application Via Google Geolocation.</p>
                        </div>
					</div>
				</div>
			</div>
		</div>
	</div>
	</footer>