<div class="site-header">
    
        <div class="main-navigation">
            <div class="responsive_menu">
                <ul>
                    
                    <li><a href="index.php">Home</a></li>
                    <li><a href="">Manage Account</a></li>
                    <li><a href="charityForm.php">Add Charity</a></li>
                    <li><a href="">Recommended Charity</a></li>

                </ul>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-md-12 responsive-menu">
                        <a href="#" class="menu-toggle-btn">
                            <i class="fa fa-bars"></i>
                        </a>
                    </div> <!-- /.col-md-12 -->
                    <div class="col-md-12 main_menu">
                        <ul>
                           <li><a href="index.php">Home</a></li>
                           <li><a href="">Manage Account</a></li>
                           <li><a href="charityForm.php">Add Charity</a></li>
                           <li><a href="">Recommended Charity</a></li>
                            
                        </ul>
                    </div> <!-- /.col-md-12 -->
                </div> <!-- /.row -->
            </div> <!-- /.container -->
        </div> <!-- /.main-navigation -->

<!-- ##################################################TUTUP LOGO##################################################### -->