<?php
	session_start();
	$name = $_SESSION['name'];
	$email = $_SESSION['email'];
	$jawatan = $_SESSION['position'];

	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else

	   include '../user/config.php';


	$select ="select * from users";
	$qSelect = mysql_query($select) or die(mysql_error());
		
	$status="";
	$semakEmail = "";
	$paparStatus = "&nbsp;";
			
	if(isset($_REQUEST['email']))
	{	
		$semakEmail= $_REQUEST['email'];
	}
	else
	{  $semakEmail=""; }
	
	if(!$semakEmail == "")
	{
		$pengguna2 = "select * from users where email = '$semakEmail'";
		$queuePengguna2 = mysql_query($pengguna2) or die(mysql_error());
		$dataPengguna2 = mysql_fetch_array($queuePengguna2);
		
		$numberRow2 = mysql_num_rows($queuePengguna2);

			if($numberRow2 == 0)
			{
				$status = "nsd";
			} 
			else
			{
				$status = "nstd";
			}
	}
	else
	{ $semakNoStaff = ""; }
	
	if(!$status == "")
	{
		if($status == "nsd")
		{
			$paparStatus = "<font face= 'Arial' color='green' size='2'>Email Accpeted</font>";
		}
		elseif($status == "nstd")
		{
			$paparStatus = "<font face= 'Arial' color='red' size='2'>Email had been registered</font>";
		}
		else
		{ $paparStatus = "&nbsp;";}
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Charity Location Tracking</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://bootstraptaste.com" />
<!-- css -->
<link href="../css/bootstrap.min.css" rel="stylesheet" />
<link href="../css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="../css/jcarousel.css" rel="stylesheet" />
<link href="../css/flexslider.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />

<!-- Theme skin -->
<link href="skins/default.css" rel="stylesheet" />

<!-- =======================================================
    Theme Name: Moderna
    Theme URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
======================================================= -->
</head>
	<!-- Main HTML -->
<body>
<div id="wrapper">
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><span>C</span>harity</a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="edit_user.php">Manage Account</a></li>
                        <li><a href="charityForm.php">Add Charity Donation</a></li>
                        <li><a href="maps.php">View Maps Location</a></li>
                        <li><a href="recommendplace.php">Recommended Charity</a></li>
                        <li><a href="proses_log_keluar.php">Log Out</a></li>      
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="#"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
					<li class="active">Manage Account</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
<!-- ########################################## close header ########################################## -->
</section>
	<section class="callaction">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="big-cta">
					<div class="cta-text">
						<h2><span>Update User Account</span></h2>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
<!-- ########################################## body ########################################## -->
 
<!-- ##################################################MAKLUMAT PENGUNA##################################################### -->
<?php
        $user = "select * from users where email = '$email'";
        $q = mysql_query($user) or die (mysql_error());
        $dataUser = mysql_fetch_array($q);
    ?>
<section id="content">
	
	<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
                <form action="user/edit_user_baru.php" method="post" role="form" class="contactForm">
                
                    <div class="form-group">
                        <input type="text" name="email" class="form-control" id="name" placeholder="<?php echo $email;?>"/>
                        
                    </div>
                    <div class="form-group">
                        <input type="text" name="password" class="form-control" id="name" placeholder="<?php echo $dataUser['password'];?>" />
                    </div>
                    <div class="form-group">
                        <input type="text" name="name" class="form-control" id="name" placeholder="<?php echo $dataUser['name'];?>" />
                    </div>
                    </div>
                    <div class="form-group">
                        <input type="text" name="ic" class="form-control" id="name" placeholder="<?php echo $dataUser['ic'];?>" />
                    </div>
                    <div class="form-group">
                        <input type="text" name="fon" class="form-control" id="name" placeholder="<?php echo $dataUser['fon'];?>" />
                    </div>
                    <div class="form-group">
                        <input type="text" name="address" class="form-control" id="name" placeholder="<?php echo $dataUser['address'];?>" />
                    </div>
                    <div class="text-center"><button type="submit" name="submit" class="btn btn-theme">UPDATE PROFILE</button></div>
                
                </form>
			</div>
		</div>
	</div>
	</section>

    <!-- #################################################TUTUP MAKLUMAT PENGGUNA###################################################### -->
	</div> <!-- /#menu-container -->
<!-- ########################################## close body ########################################## -->	
<!-- ########################################## footer ########################################## -->	
<?php include ('bottom.php');?>
	
<!-- ########################################## close footer ########################################## -->	
	<!-- End Page Content -->
<!-- ########################################## close footer ########################################## -->	
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>
<!-- javascript
    ================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="../js/jquery.js"></script>
<script src="../js/jquery.easing.1.3.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/jquery.fancybox.pack.js"></script>
<script src="../js/jquery.fancybox-media.js"></script>
<script src="../js/google-code-prettify/prettify.js"></script>
<script src="../js/portfolio/jquery.quicksand.js"></script>
<script src="../js/portfolio/setting.js"></script>
<script src="../js/jquery.flexslider.js"></script>
<script src="../js/animate.js"></script>
<script src="../js/custom.js"></script>
<script src="../contactform/contactform.js"></script>
</body>
</html>
	
	
	
		
	