<?php
    session_start();
 	include '../user/config.php';
	
	$charityId = $_POST['charityId'];
	$name = $_POST['name'];
	$fon= $_POST['fon'];
	$category = $_POST['category'];
	$desc = $_POST['desc'];
	$address = $_POST['address'];
	$name2 = basename($_FILES['picture']['name']);
	$address2 = $_FILES['picture']['tmp_name'];
	$folder= "picture";
	$direction = "picture";


	
	$s = mysql_query("select * from picture") or die (mysql_error());
	$qs = mysql_num_rows($s);
	$pictureId = $qs + 1;
	
	if(move_uploaded_file($address2,$direction."/(".$charityId.")".$name2))
	{
		$c = $folder."/(".$charityId.")".$name2;
		$s = "insert into picture values('$pictureId','$name','$c)";
			mysql_query($s) or die (mysql_error());
		
			mysql_query("insert into charity values ('$charityId','$name','$fon','$category','$desc','$address')") or die (mysql_error());
			
			
			$maklum = $charityId." Charity information successfully added!";
			
			header("Location:index.php?status=$maklum");
			
		}
	else
	{
		echo "Error!!";
	}
	?>