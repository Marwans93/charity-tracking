<?php
	session_start();
	$name = $_SESSION['name'];
	$email = $_SESSION['email'];
	$jawatan = $_SESSION['position'];
	
	if(!$_SESSION['register'])
		header('Location:../index.php');
	
	else
	{
		include 'user/connection.php';
		
		
		$status = "";
		$paparStatus = "";
		
		if(isset($_REQUEST['submit']))
		{ $klik = $_REQUEST['submit']; }
		else { $klik = ""; }
		
		if(!$klik =="")
		{
			$email=$_POST['email'];
			$password=$_POST['password'];
			$name=$_POST['name'];
			$ic = $_POST['ic'];
			$fon = $_POST['fon'];
			$address = $_POST['address'];


	
			$user = "update users
				set	email = '$email',
					password = '$password',
					name = '$name',
					ic = '$ic',
					fon = '$fon',
				    address = '$address'
				    where email = '$email'";
			$simpanUser = mysql_query($user) or die(mysql_error());

			$status = "kb";
		}
		
		
		if(!$status == "")
		{
			if($status == "kb")
			{ $paparStatus = "<font face='Arial, sans-serif' color='green' size='3'>Kemaskini Berjaya!</font>"; }
			else{ $paparStatus = "<font face='Arial, sans-serif' color='Red' size='3'>Kemaskini Gagal!</font>";}
		}
		else{ $paparStatus = "&nbsp;";}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Charity Location Tracking</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" content="http://bootstraptaste.com" />
<!-- css -->
<link href="../css/bootstrap.min.css" rel="stylesheet" />
<link href="../css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="../css/jcarousel.css" rel="stylesheet" />
<link href="../css/flexslider.css" rel="stylesheet" />
<link href="../css/style.css" rel="stylesheet" />

<!-- Theme skin -->
<link href="skins/default.css" rel="stylesheet" />

<!-- =======================================================
    Theme Name: Moderna
    Theme URL: https://bootstrapmade.com/free-bootstrap-template-corporate-moderna/
    Author: BootstrapMade
    Author URL: https://bootstrapmade.com
======================================================= -->
</head>
	<!-- Main HTML -->
<body>
<div id="wrapper">
	<!-- start header -->
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php"><span>C</span>harity</a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="edit_user.php">Manage Account</a></li>
                        <li><a href="charityForm.php">Add Charity Donation</a></li>
                        <li><a href="maps.php">View Maps Location</a></li>
                        <li><a href="recommendplace.php">Recommended Charity</a></li>
                        <li><a href="proses_log_keluar.php">Log Out</a></li>      
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<section id="inner-headline">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<ul class="breadcrumb">
					<li><a href="#"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
					<li class="active">Manage Account</li>
				</ul>
			</div>
		</div>
	</div>
	</section>
<!-- ########################################## close header ########################################## -->
</section>
	<section class="callaction">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="big-cta">
					<div class="cta-text">
						<h2><span>Update User Account</span></h2>
					</div>
				</div>
			</div>
		</div>
	</div>
	</section>
<body id="top">

 <?php
  
  //SQL untuk papar semua biodata
  
	$pekerja = "select * from pekerja where pekerjaID = '$noStaff'";
	$queryPekerja = mysql_query($pekerja) or die (mysql_error());
	$dataPekerja = mysql_fetch_array($queryPekerja);
  
  ?>
     <div align="center">
	<?php echo $paparStatus; ?>
	</div>
<div class="wrapper">
<div class="container">
	
<br>
  <form action="user_edit_baru.php" method="post">
  <table border="1">
  <tr>
  <thead>
  	<th colspan="3"><font face="Arial, Helvetica, sans-serif" size="2">Kemaskini Biodata</font></th>
    </thead>
  </tr> 
  <tr class="light">
  	<td width="24"><font face="Arial, Helvetica, sans-serif" size="2">Nombor Staf</font> <font face="Arial, Helvetica, sans-serif" color="#FF0000" size="2">****</font></td>
    <td width="1%">:</td>
    <td width="75%"><input type="text" name="noStaff" id="noStaff" value="<?php echo $noStaff;?>" size="100" readonly /></td>
    </tr>
    <tr class="light">
    	<td><font face="Arial, Helvetica, sans-serif" size="2">Nama</font> <font face="Arial, Helvetica, sans-serif" color="#FF0000" size="2"> ****</font></td>
        <td>:</td>
        <td><input type="text" name="nama" id="nama" value="<?php echo $nama;?>" size="100" readonly/></td>
    </tr>
    <tr class="light">
    	<td><font face="Arial, Helvetica, sans-serif" size="2">Nombor IC</font></td>
        <td>:</td>
        <td><input type="text" name="noIC" id="noIC" value="<?php echo $dataPekerja['pekerjaIC'];?>" size="100"/></td>
     </tr>
     <tr class="light">
     	<td><font face="Arial, Helvetica, sans-serif" size="2">Jabatan </font></td>
        <td>:</td>
        <td><select name="jabatan">
                    <?php
						
          			$qs = "select * from jabatan";
          			$rowqs = mysql_query($qs) or die(mysql_error());
          			while ($data = mysql_fetch_array($rowqs))
          			{
						
	       				if ($dataPekerja['pekerjaJabatan']==$data["jabatanNama"])
	        					{ 
								?>
									
					      <option value ="<?php echo $data['jabatanNama']; 
						  ?>" selected> <?php echo $data['jabatanNama']; ?>
                          <?php  	}
	       						else
            					{ ?>
                          </option>
					      <option value ="<?php echo $data['jabatanNama']; ?>" ><?php echo $data['jabatanNama']; ?>
                          <?php 		}
          					} ?>
                          </option>
				        </select></td>
         </tr>
		 <tr class="light">
			<td><font face="Arial, Helvetica, sans-serif" size="2">Nombor Telifon</font></td>
			<td>:</td>
			<td><input type="text" name="noTel" id="noTelifon" value="<?php echo $dataPekerja['pekerjaTelifon'];?>" size="100"/></td>
		</tr>
         <tr class="light">
          	<td><font face="Arial, Helvetica, sans-serif" size="2">Email</font> </td>
            <td>:</td>
            <td><input type="text" name="email" id="email" value="<?php echo $dataPekerja['pekerjaEmail'];?>" size="100"/></td>
           </tr>
         </table>
         <div id="respond" align="center">
         	<input name="submit" type="submit" id="submit" value="Simpan" />
            &nbsp;
            <input name="reset" type="reset" id="reset" tabindex="5" value="Kembali Asal" />
            &nbsp;
            <a href="index.php"><input type="button" id="submit" value="Balik Kepada Biodata" /></a>
                   </div> </form>	     
            <br /><br>
		  <small>Petunjuk : <font face="Arial, Helvetica, sans-serif" color="#FF0000" size="2">****</font> >> Perlu minta kebenaran dari admin untuk kemaskini. <a href="lihat_biodata_kemaskini_pohon.php">Klik disini.</a></small>
		  <br>
          </p>
 
     
      </font>
    </div>
    <br class="clear" />
</div>
<!-- #################################################TUTUP BODY###################################################### -->
<!-- #####################################################SPACE################################################## -->
<div id="adblock">
<br class="clear" />
</div>
<!-- #################################################TUTUP SPACE###################################################### -->

<!-- ##############################################BOTTOM######################################################### -->
<?php include '../footer.php';?>
<!-- ##############################################TUTuP BOTTOM######################################################### -->
</body>
</html>
<?php
}
?>
